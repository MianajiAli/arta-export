const ProductInfo = () => {
    return (
        <div>
            Enter
        </div>
    );
}

export default ProductInfo;